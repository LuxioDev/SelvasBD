Gabi: 
-
- Agregar la columna "precio" en historial_de_movimientos.py de la carpeta 'gestor' 
- Mostrar de manera mas organizada y entendible el producto comprado/modificado en el historial de movimientos de usuario y gestor, es decir, que no aparezca 1 sino que aparezca el nombre del producto y usuario en caso del gestor

Mati:
-
- En el momento de realizar la carga al control de stock guardar: 
El nombre del usuario que realizó dicha carga. 
El estado del producto según Stock.
Recordad que esta prohibido borrar datos.
Fecha de alta.
Precio.

Luxio: 
-

+ tarea
