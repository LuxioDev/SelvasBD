usuario_actual = None
